
function Error({mensaje}) {
  return (
    <div className="bg-red-600 text-white p-2 rounded-sm mb-3 uppercase">
      <p className="text-center font-bold">{mensaje}</p>
    </div>
  )
}

export default Error